﻿class Potega_N2
{
    // Nieprawidłowe, pętla for
    public static decimal Power(int n, int w)
    {
        if (n == 0 && w == 0)
        {
            throw new System.ArgumentException("n == 0 && w == 0");
        }
        if (n == 0)
        {
            return 0;
        }
        if (w == 0)
            return 1;
        var wAbs = w;
        if (w < 0)
            wAbs = -w;
        int p = n;
        for (int i = 1; i < wAbs; i++)
        {
            if (int.MaxValue < (long)p * n)
                throw new System.ArgumentException("Parameters too big or too small.");
            p = p * n;
        }
        return p;
    }
}
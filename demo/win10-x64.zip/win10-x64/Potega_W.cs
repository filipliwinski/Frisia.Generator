﻿class Potega_W
{
    // WZÓR Prawidłowe, pętla while
    public static decimal Power(int n, int w)
    {
        if (w == int.MinValue)
            throw new System.ArgumentException("w == " + int.MinValue);
        if (n == 0)
        {
            if (w == 0)
                throw new System.ArgumentException("n == 0 && w == 0");
            return 0;
        }
        if (w == 0)
            return 1;
        var wAbs = w;
        if (w < 0)
            wAbs = -w;
        int p = n;
        int i = 1;
        while (i < wAbs)
        {
            if (int.MaxValue < (long)p * n)
                throw new System.ArgumentException("Parameters too big or too small.");
            p = p * n;
            i = i + 1;
        }
        if (w > 0)
            return p;
        return (decimal)1 / p;
    }
}